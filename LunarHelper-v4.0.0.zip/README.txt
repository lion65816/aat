For information on Lunar Helper and related tools, see: https://github.com/Underrout/LunarHelper/wiki

If the link above ever becomes unavailable, a copy of the wiki is included in the "Documentation" folder, though I would highly recommend viewing the online version instead, if possible.
