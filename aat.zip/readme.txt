Current version: 1.0

And Another Thing (AAT) is the third in a series of SMW collab hacks produced
by the Talkhaus featuring Demo Roseclair, a blue-haired Armless Bipedal
Cycloptic Demon who also serves as the community's mascot. Demo and her sister
Iris are tasked with preparing an enormous feast for an important holiday...
only to discover that there's no food left in their fridge! Will they find a
grocery store in time?

Highlights:

- Standard: Very Hard difficulty
- 122 exits
- 8 MB SA-1 ROM
- Play as Demo or Iris
- Several new custom bosses
- Collectibles tracking
- Death counter
- And more...

Recommended emulators:

This hack was tested extensively using both Mesen 2 and Snes9x v1.62.3, so we
recommend these emulators for playing. There may be some graphical glitches
present when using bsnes v115, although there shouldn't be anything game-
breaking.

Credits list:

https://docs.google.com/spreadsheets/d/1YrcuZg9DnHJWshEXCZL-O_vlvc7Sl_WYvWqbp_Cyxcw/edit?gid=1345832325#gid=1345832325
